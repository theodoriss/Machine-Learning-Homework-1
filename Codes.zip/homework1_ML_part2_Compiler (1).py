#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
from sklearn.feature_extraction.text import HashingVectorizer
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.feature_extraction.text import *
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import *
from sklearn.metrics import confusion_matrix, classification_report
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import ShuffleSplit
from sklearn.model_selection import cross_val_score
from sklearn import svm
from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.naive_bayes import MultinomialNB
from sklearn.model_selection import GridSearchCV



# In[2]:


cd "C:\Users\Theo\Downloads"


# In[45]:


data= pd.DataFrame.from_csv('ML_HW1_data.csv')


# In[19]:


data.head()


# In[4]:


vectorizer = HashingVectorizer(ngram_range=(5,7),analyzer='word') # multivariate


# In[33]:


#vectorizer = HashingVectorizer(ngram_range=(3,9),analyzer='word') # multivariate


# In[5]:


X_all = vectorizer.fit_transform(data.instructions)
y_all = data.compiler


# In[38]:


X_all.shape


# In[8]:


#from sklearn import random_projection


# In[9]:


#transformer = random_projection.SparseRandomProjection()


# In[10]:


#X_new=transformer.fit_transform(X_all)


# In[11]:


#_new.shape


# ### try a logistic regression for multiclass classification

# In[6]:


X_train, X_test, y_train, y_test = train_test_split(X_all, y_all, 
          test_size=0.2, random_state=1453)


# In[7]:


model= LogisticRegression(multi_class='multinomial',solver='newton-cg').fit(X_train,y_train)


# In[36]:


y_pred = model.predict(X_test)
print(confusion_matrix(y_test, y_pred))
print(classification_report(y_test, y_pred))


# In[37]:


cv = ShuffleSplit(n_splits=5, test_size=0.333, random_state=120)
scores = cross_val_score(model, X_all, y_all, cv=cv)
print(scores)
print("Accuracy: %0.3f (+/- %0.2f)" % (scores.mean(), scores.std() * 2))
  


# ### Try a Decision Tree Classifier

# In[10]:


model0 = DecisionTreeClassifier().fit(X_train,y_train)


# In[11]:


y_pred = model0.predict(X_test)
print(confusion_matrix(y_test, y_pred))
print(classification_report(y_test, y_pred))


# In[21]:


cv = ShuffleSplit(n_splits=5, test_size=0.333, random_state=120)
scores = cross_val_score(model0, X_all, y_all, cv=cv)
print(scores)
print("Accuracy: %0.3f (+/- %0.2f)" % (scores.mean(), scores.std() * 2))


# ### Create a linear svm classification, one over all

# In[18]:


model1=svm.SVC(gamma='scale',kernel='linear',cache_size=4000,decision_function_shape='ovo').fit(X_train,y_train)


# In[19]:


y_pred = model1.predict(X_test)
print(confusion_matrix(y_test, y_pred))
print(classification_report(y_test, y_pred))


# In[38]:


model2 = svm.LinearSVC().fit(X_train,y_train)


# In[39]:


y_pred = model2.predict(X_test)
print(confusion_matrix(y_test, y_pred))
print(classification_report(y_test, y_pred,labels=['clang','gcc','icc']))


# ### try a random forest classifier,compiled of 100 decision trees

# In[21]:


model3=RandomForestClassifier(n_estimators=100,n_jobs=4).fit(X_train,y_train)


# In[22]:


y_pred = model3.predict(X_test)
print(confusion_matrix(y_test, y_pred))
print(classification_report(y_test, y_pred,labels=['clang','gcc','icc']))


# In[23]:


cv = ShuffleSplit(n_splits=5, test_size=0.333, random_state=120)
scores = cross_val_score(model3, X_all, y_all, cv=cv)
print(scores)
print("Accuracy: %0.3f (+/- %0.2f)" % (scores.mean(), scores.std() * 2))
  


# ### naive bayes classifier

# In[46]:


vectorizer = HashingVectorizer(ngram_range=(5,7),analyzer='word',non_negative=True) # multivariate


# In[47]:


X_all = vectorizer.fit_transform(data.instructions)
y_all = data.compiler


# In[48]:


X_train, X_test, y_train, y_test = train_test_split(X_all, y_all, 
          test_size=0.2, random_state=1453)


# In[18]:


model4 = MultinomialNB(fit_prior=True).fit(X_train,y_train)


# In[19]:


y_pred = model4.predict(X_test)
print(confusion_matrix(y_test, y_pred))
print(classification_report(y_test, y_pred))


# In[20]:


cv = ShuffleSplit(n_splits=5, test_size=0.333, random_state=120)
scores = cross_val_score(model4, X_all, y_all, cv=cv)
print(scores)
print("Accuracy: %0.3f (+/- %0.2f)" % (scores.mean(), scores.std() * 2))
  


# ### Perform a grid search on naive bayes hyperparameters

# In[28]:


grid_values = {'fit_prior': ['True', 'False'],'alpha':[0.001,0.01,0.1,1,5,10]}
grid_acc = GridSearchCV(model4, param_grid = grid_values,scoring = 'accuracy',cv=5,iid=False,n_jobs=4).fit(X_all,y_all)


# In[29]:


for i in range(0,len(grid_acc.cv_results_['params'])):
    print("[%2d] params: %s  \tscore: %.3f +/- %.3f" %(i,
        grid_acc.cv_results_['params'][i],
        grid_acc.cv_results_['mean_test_score'][i],
        grid_acc.cv_results_['std_test_score'][i] ))

a = np.argmax(grid_acc.cv_results_['mean_test_score'])
bestparams = grid_acc.cv_results_['params'][a]
bestscore = grid_acc.cv_results_['mean_test_score'][a]

print("Best configuration [%d] %r  %.3f" %(a,bestparams,bestscore))


# In[49]:


model5 = MultinomialNB(fit_prior=True,alpha=0.01).fit(X_train,y_train)


# In[50]:


y_pred = model5.predict(X_test)
print(confusion_matrix(y_test, y_pred))
print(classification_report(y_test, y_pred))


# ### Predict the optimizer for the blind test set

# In[36]:


def create_table_2(name_of_file):
    dictionary=dict()
    with open(name_of_file,"r") as data:
        for number,line in enumerate(data):
            instructions=[]
            instr= line.strip('{"instructions": [').split("],")[0].replace('"','')
            for i in range(len(instr.split(', '))):
                try:
                    instructions.append(instr.split(', ')[i].split()[0])

                except:
                    print('error or instance  '+str(i)+ 'and number  '+str(number)+ 'with text:   '+ str(instr.split(', ')[i].split()))

           

            dictionary[number]=[' '.join(instructions).strip(']}')]
    return dictionary


# In[37]:


data_test= pd.DataFrame.from_dict(create_table_2("test_dataset_blind.jsonl"),orient='index',columns=['instructions'])


# In[51]:


data_test.head()


# In[52]:


X_all_test = vectorizer.fit_transform(data_test.instructions) # the vectorizer of naive bayes with non negative values


# In[53]:


compiler_predictions = model5.predict(X_all_test)


# In[56]:


sum(compiler_predictions=='clang')


# In[57]:


sum(compiler_predictions=='gcc')


# In[58]:


sum(compiler_predictions=='icc')


# In[54]:


compiler_predictions


# In[55]:


np.savetxt("ML_HW1_compilers_predictions.csv", compiler_predictions,fmt='%s')


# In[ ]:




