#!/usr/bin/env python
# coding: utf-8

# In[2]:


import json
import pandas as pd
import numpy as np
from sklearn.feature_extraction.text import HashingVectorizer
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.feature_extraction.text import *
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import *
from sklearn.metrics import confusion_matrix, classification_report
from sklearn.model_selection import learning_curve
from sklearn.linear_model import LogisticRegression
from sklearn import svm
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import ShuffleSplit
from sklearn.model_selection import cross_val_score
from sklearn.model_selection import GridSearchCV
from sklearn.metrics import f1_score
from sklearn.model_selection import StratifiedKFold


# In[3]:


cd "C:\Users\Theo\Downloads"


# In[16]:


def create_table(name_of_file):
    dictionary=dict()
    with open(name_of_file,"r") as data:
        for number,line in enumerate(data):
            instructions=[]
            instr= line.strip('{"instructions": [').split("],")[0].replace('"','')
            for i in range(len(instr.split(', '))):
                try:
                    instructions.append(instr.split(', ')[i].split()[0])

                except:
                    print('error or instance  '+str(i)+ 'and number  '+str(number)+ 'with text:   '+ str(instr.split(', ')[i].split()))

            rest= line.strip('{"instructions": [').split("],")[1].replace('"','').replace('}','').replace(',','').split()
                #print(rest[1]) # number 1 is the optimizer and number 3 is the compiler
            optimizer = rest[1]
            compiler=rest[3]

            dictionary[number]=[' '.join(instructions),rest[1],rest[3]]
    return dictionary


# In[ ]:


data= pd.DataFrame.from_dict(create_table("train_dataset.jsonl"),orient='index',columns=['instructions','optimizer','compiler'])


# In[ ]:


data.to_csv(r'ML_HW1_data.csv')


# In[4]:


data= pd.DataFrame.from_csv('ML_HW1_data.csv')


# In[5]:


sum(data['optimizer']=='L')


# In[6]:


sum(data['optimizer']=='L')/30000


# In[5]:


vectorizer = HashingVectorizer(ngram_range=(5,7),analyzer='word') # multivariate


# In[6]:


X_all = vectorizer.fit_transform(data.instructions)
y_all = data.optimizer


# In[7]:


X_train, X_test, y_train, y_test = train_test_split(X_all, y_all, 
          test_size=0.2, random_state=1453)


# ### Try a logistic regression model

# In[11]:


model1= LogisticRegression().fit(X_train,y_train)


# In[12]:


y_pred = model1.predict(X_test)
print(confusion_matrix(y_test, y_pred))
print(classification_report(y_test, y_pred))
print('accuracy is:  '+str((confusion_matrix(y_test, y_pred)[0][0]+confusion_matrix(y_test, y_pred)[1][1])/(confusion_matrix(y_test, y_pred)[0].sum()+confusion_matrix(y_test, y_pred)[1].sum())))


# In[13]:


cv = StratifiedKFold(n_splits=5,random_state=120,shuffle=True)
scores = cross_val_score(model1, X_all, y_all, cv=cv,scoring='f1_weighted')
print(scores)
print("Weighted f1 score : %0.3f (+/- %0.2f)" % (scores.mean(), scores.std() * 2))


# ### Grid Search for logistic regression

# In[16]:


grid_values = {'penalty': ['l1', 'l2'],'C':[0.01,.09,0.1,1,5,10,25,50,100]}
grid_acc = GridSearchCV(model1, param_grid = grid_values,scoring = 'f1_weighted',cv=cv,iid=False,n_jobs=4).fit(X_all,y_all)


# In[17]:


for i in range(0,len(grid_acc.cv_results_['params'])):
    print("[%2d] params: %s  \tscore: %.3f +/- %.3f" %(i,
        grid_acc.cv_results_['params'][i],
        grid_acc.cv_results_['mean_test_score'][i],
        grid_acc.cv_results_['std_test_score'][i] ))

a = np.argmax(grid_acc.cv_results_['mean_test_score'])
bestparams = grid_acc.cv_results_['params'][a]
bestscore = grid_acc.cv_results_['mean_test_score'][a]

print("Best configuration [%d] %r  %.3f" %(a,bestparams,bestscore))


# In[8]:


model15= LogisticRegression(C=100).fit(X_train,y_train)


# In[9]:


y_pred = model15.predict(X_test)
print(confusion_matrix(y_test, y_pred))
print(classification_report(y_test, y_pred))
print('accuracy is:  '+str((confusion_matrix(y_test, y_pred)[0][0]+confusion_matrix(y_test, y_pred)[1][1])/(confusion_matrix(y_test, y_pred)[0].sum()+confusion_matrix(y_test, y_pred)[1].sum())))


# ### try a linear support vector machines model

# In[20]:


model2=svm.SVC(gamma='scale',kernel='linear',cache_size=40000).fit(X_train,y_train)


# In[21]:


y_pred = model2.predict(X_test)
print(confusion_matrix(y_test, y_pred))
print(classification_report(y_test, y_pred))
print('accuracy is:  '+str((confusion_matrix(y_test, y_pred)[0][0]+confusion_matrix(y_test, y_pred)[1][1])/(confusion_matrix(y_test, y_pred)[0].sum()+confusion_matrix(y_test, y_pred)[1].sum())))


# ### try 2 decision trees, with different loss criteria classifier
# 

# In[34]:


model3=DecisionTreeClassifier().fit(X_train, y_train)


# In[35]:


y_pred = model3.predict(X_test)
print(confusion_matrix(y_test, y_pred))
print(classification_report(y_test, y_pred))
print('accuracy is:  '+str((confusion_matrix(y_test, y_pred)[0][0]+confusion_matrix(y_test, y_pred)[1][1])/(confusion_matrix(y_test, y_pred)[0].sum()+confusion_matrix(y_test, y_pred)[1].sum())))


# In[36]:


cv = StratifiedKFold(n_splits=5,random_state=120,shuffle=True)
scores = cross_val_score(model3, X_all, y_all, cv=cv,scoring='f1_weighted')
print(scores)
print("Weighted f1 score : %0.3f (+/- %0.2f)" % (scores.mean(), scores.std() * 2))


# In[25]:


model4 = DecisionTreeClassifier(criterion='entropy').fit(X_train,y_train)


# In[26]:


y_pred = model4.predict(X_test)
print(confusion_matrix(y_test, y_pred))
print(classification_report(y_test, y_pred))
print('accuracy is:  '+str((confusion_matrix(y_test, y_pred)[0][0]+confusion_matrix(y_test, y_pred)[1][1])/(confusion_matrix(y_test, y_pred)[0].sum()+confusion_matrix(y_test, y_pred)[1].sum())))


# In[27]:


cv = StratifiedKFold(n_splits=5,random_state=120,shuffle=True)
scores = cross_val_score(model4, X_all, y_all, cv=cv,scoring='f1_weighted')
print(scores)
print("Weighted f1 score : %0.3f (+/- %0.2f)" % (scores.mean(), scores.std() * 2))


# ### try a random forest, consisting of 100 decision trees

# In[28]:


model5=RandomForestClassifier(n_estimators=100).fit(X_train,y_train)


# In[29]:


y_pred = model5.predict(X_test)
print(confusion_matrix(y_test, y_pred))
print(classification_report(y_test, y_pred))
print('accuracy is:  '+str((confusion_matrix(y_test, y_pred)[0][0]+confusion_matrix(y_test, y_pred)[1][1])/(confusion_matrix(y_test, y_pred)[0].sum()+confusion_matrix(y_test, y_pred)[1].sum())))


# In[30]:


cv = StratifiedKFold(n_splits=5,random_state=120,shuffle=True)
scores = cross_val_score(model5, X_all, y_all, cv=cv,scoring='f1_weighted')
print(scores)
print("Weighted f1 score : %0.3f (+/- %0.2f)" % (scores.mean(), scores.std() * 2))


# In[ ]:


### if the compilers affect the optimization. the last part of stratified, which is with compiler icc? seems to have many H, so the score is low.


# In[ ]:


### the problem is the low recall of the High optimization. with grid search, logistic regression smv too, seem to solve it.


# ### Try a knn classifier

# In[7]:


model6 = KNeighborsClassifier(n_neighbors=10,weights='distance').fit(X_train,y_train)


# In[9]:


y_pred = model6.predict(X_test)
print(confusion_matrix(y_test, y_pred))
print(classification_report(y_test, y_pred))
print('accuracy is:  '+str((confusion_matrix(y_test, y_pred)[0][0]+confusion_matrix(y_test, y_pred)[1][1])/(confusion_matrix(y_test, y_pred)[0].sum()+confusion_matrix(y_test, y_pred)[1].sum())))


# In[10]:


cv = StratifiedKFold(n_splits=5,random_state=120,shuffle=True)
scores = cross_val_score(model6, X_all, y_all, cv=cv,scoring='f1_weighted')
print(scores)
print("Weighted f1 score : %0.3f (+/- %0.2f)" % (scores.mean(), scores.std() * 2))


# ### try a naive bayes multinomial classifier

# In[11]:


vectorizer = HashingVectorizer(ngram_range=(5,7),analyzer='word',non_negative=True) # non negative values are changed, so we can implement bayes
X_all = vectorizer.fit_transform(data.instructions)
y_all = data.optimizer
X_train, X_test, y_train, y_test = train_test_split(X_all, y_all, 
          test_size=0.2, random_state=1453)


# In[12]:


model7 = MultinomialNB(fit_prior=True).fit(X_train,y_train)


# In[13]:


y_pred = model7.predict(X_test)
print(confusion_matrix(y_test, y_pred))
print(classification_report(y_test, y_pred))
print('accuracy is:  '+str((confusion_matrix(y_test, y_pred)[0][0]+confusion_matrix(y_test, y_pred)[1][1])/(confusion_matrix(y_test, y_pred)[0].sum()+confusion_matrix(y_test, y_pred)[1].sum())))


# In[14]:


cv = StratifiedKFold(n_splits=5,random_state=120,shuffle=True)
scores = cross_val_score(model7, X_all, y_all, cv=cv,scoring='f1_weighted')
print(scores)
print("Weighted f1 score : %0.3f (+/- %0.2f)" % (scores.mean(), scores.std() * 2))


# ### Predict the optimizer for the blind test set

# In[10]:


def create_table_2(name_of_file):
    dictionary=dict()
    with open(name_of_file,"r") as data:
        for number,line in enumerate(data):
            instructions=[]
            instr= line.strip('{"instructions": [').split("],")[0].replace('"','')
            for i in range(len(instr.split(', '))):
                try:
                    instructions.append(instr.split(', ')[i].split()[0])

                except:
                    print('error or instance  '+str(i)+ 'and number  '+str(number)+ 'with text:   '+ str(instr.split(', ')[i].split()))

           

            dictionary[number]=[' '.join(instructions).strip(']}')]
    return dictionary


# In[11]:


data_test= pd.DataFrame.from_dict(create_table_2("test_dataset_blind.jsonl"),orient='index',columns=['instructions'])


# In[12]:


data_test.head()


# In[13]:


X_all_test = vectorizer.fit_transform(data_test.instructions)


# In[14]:


optimizer_predictions = model15.predict(X_all_test)


# In[15]:


optimizer_predictions


# In[16]:


sum(optimizer_predictions=='H')


# In[17]:


sum(optimizer_predictions=='L')


# In[18]:


np.savetxt("ML_HW1_optimizers_predictions.csv", optimizer_predictions,fmt='%s')


# In[ ]:




